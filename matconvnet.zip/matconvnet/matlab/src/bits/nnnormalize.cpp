#ifdef ENABLE_GPU
#error "The file nnnormalize.cu should be compiled instead"
#endif
#include "nnnormalize.cu"
