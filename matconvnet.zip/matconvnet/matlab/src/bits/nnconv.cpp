#ifdef ENABLE_GPU
#error "The file nnconv.cu should be compiled instead"
#endif
#include "nnconv.cu"
